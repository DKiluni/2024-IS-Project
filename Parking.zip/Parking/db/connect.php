<?php

try{
    $pdo = new PDO('mysql:host=localhost;dbname=parking','root','');
    //echo 'Connection is Successfull';
}catch(PDOException $error){
    echo $error->getmessage();
}


?>