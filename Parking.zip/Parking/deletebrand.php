<?php
 include_once'db/connect.php';
 session_start();
 if($_SESSION['role']!=="admin"){
   header('location:index.php');
 }

$delete = $pdo->prepare("DELETE FROM brand WHERE id = '".$_GET['id']." '");
if($delete->execute()){
    header('location:vehiclebrand.php');
}


