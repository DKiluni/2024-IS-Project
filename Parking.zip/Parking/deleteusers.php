<?php
 include_once'db/connect.php';
 session_start();
 if($_SESSION['role']!=="admin"){
   header('location:index.php');
 }

$delete = $pdo->prepare("DELETE FROM users WHERE id = '".$_GET['id']." '");
if($delete->execute()){
    header('location:users.php');
}


