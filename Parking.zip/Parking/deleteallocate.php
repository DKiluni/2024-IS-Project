<?php
include_once 'db/connect.php';
session_start();

if ($_SESSION['role'] !== "admin") {
    header('location:index.php');
    exit();
}

if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    $id = $_GET['id'];

    $delete = $pdo->prepare("DELETE FROM report WHERE id = :id");
    $delete->bindParam(':id', $id, PDO::PARAM_INT);

    if ($delete->execute()) {
        header('location:allocate.php');
        exit();
    } else {
        echo "Error: Unable to delete the allocation.";
    }
} else {
    echo "Error: Invalid ID.";
}

