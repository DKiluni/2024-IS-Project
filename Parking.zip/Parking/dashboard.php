<?php
    include_once'db/connect.php';
    session_start();
    if($_SESSION['role']=="admin"){
      include_once'head/adminheader.php';
    }else{
        include_once'head/guardheader.php';
    }
?>
<div class="content-wrapper">
    <section class="content container-fluid">
      <div class="row">
	  
	   <?php
        $select = $pdo->prepare("SELECT count(ID) as j FROM users");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total = $row->j;
        ?>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Users</span>
              <span class="info-box-number"><small><?php echo $row->j ?></small></span>
            </div>
          </div>
        </div>

        <?php
        $select = $pdo->prepare("SELECT count(ID) as total FROM vehicles");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total1 = $row->total;
        ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-car"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Vehicles</span>
              <?php if($total1==true){ ?>
              <span class="info-box-number"><small><?php echo $row->total;?></small></span>
              <?php }else{?>
              <span class="info-box-text"><strong>None</strong></span>
              <?php }?>
            </div>
          </div>
        </div>

        <?php
        $select = $pdo->prepare("SELECT count(ID) as i FROM slots");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $invoice = $row->i ;
        ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-list"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Slots</span>
              <span class="info-box-number"><small><?php echo $row->i ?></small></span>
            </div>
          </div>
        </div>


        <?php
        $select = $pdo->prepare("SELECT count(ID) as t FROM report WHERE date = CURDATE()");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total = $row->t;
        ?>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-question"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Total Daily Parkings</span>
              <span class="info-box-number"><small><?php echo $row->t ?></small></span>
            </div>
          </div>
        </div>

		<?php
        $select = $pdo->prepare("SELECT count(ID) as m FROM slots WHERE is_occupied = 1");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total = $row->m;
        ?>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-lock"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Occupied Slots</span>
              <span class="info-box-number"><small><?php echo $row->m ?></small></span>
            </div>
          </div>
        </div>	

		<?php
        $select = $pdo->prepare("SELECT count(ID) as m FROM slots WHERE is_occupied = 0 AND location = 'Phase 1'");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total = $row->m;
        ?>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-unlock"></i></span>

            <div class="info-box-content">
              <span class="info-box-text"><strong>Phase 1</strong> Empty Slots</span>
              <span class="info-box-number"><small><?php echo $row->m ?></small></span>
            </div>
          </div>
        </div>	

		<?php
        $select = $pdo->prepare("SELECT count(ID) as m FROM slots WHERE is_occupied = 0 AND location = 'Phase 2'");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total = $row->m;
        ?>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-unlock"></i></span>

            <div class="info-box-content">
              <span class="info-box-text"><strong>Phase 2</strong> Empty Slots</span>
              <span class="info-box-number"><small><?php echo $row->m ?></small></span>
            </div>
          </div>
        </div>	

		<?php
        $select = $pdo->prepare("SELECT count(ID) as m FROM slots WHERE is_occupied = 0 AND location = 'Phase 3'");
        $select->execute();
        $row=$select->fetch(PDO::FETCH_OBJ);
        $total = $row->m;
        ?>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-unlock"></i></span>

            <div class="info-box-content">
              <span class="info-box-text"><strong>Phase 3</strong> Empty Slots</span>
              <span class="info-box-number"><small><?php echo $row->m ?></small></span>
            </div>
          </div>
        </div>	
		
      </div>

      <div class="col-md-offset-1 col-md-10">
        <div class="box box-success">
          <div class="box-header with-border">
              <h3 class="box-title">List of Parked Vehicles</h3>
          </div>
          <div class="box-body">
              <div style="overflow-x:auto;">
                  <table class="table table-striped" id="myBestProduct">
                      <thead>
                          <tr>
                              <th>No</th>
                              <th>Registration Plate</th>
                              <th>Brand</th>
							  <th>Model</th>
                              <th>Colour</th>
                              <th>Owner</th>
                              <th>Contact</th>
							  <th>Role</th>
							  <th>Slot Number</th>
							  <th>Served By</th>
                          </tr>

                      </thead>
                      <tbody>
                          <?php
                         $no = 1;
							$select = $pdo->prepare("SELECT Registration_Plate,Brand,Model,Colour,Owner,Contact,roles,Slot_Number,served_by FROM
                         report WHERE DATE(date) = CURDATE()");
                          $select->execute();
                          while($row=$select->fetch(PDO::FETCH_OBJ)){
                          ?>
                              <tr>
                              <td><?php echo $no++ ;?></td>
                              <td><?php echo $row->Registration_Plate; ?></td>
                              <td><?php echo $row->Brand; ?></td>
							  <td><?php echo $row->Model; ?></td>
							  <td><?php echo $row->Colour; ?></td>
                              <td><?php echo $row->Owner; ?></td>
							  <td><?php echo $row->Contact; ?></td>
							  <td><?php echo $row->roles; ?></td>
							  <td><?php echo $row->Slot_Number; ?></td>
							  <td><?php echo $row->served_by; ?></td>
							  
                              </tr>
	
                        <?php
                          }
                        ?>
                      </tbody>
                  </table>
              </div>
            </div>
          </div>
        
      </div>
    </section>
  </div>
  <script>
  $(document).ready( function () {
      $('#myBestProduct').DataTable();
  } );
  </script>


 <?php
    include_once'head/footer.php';
 ?>