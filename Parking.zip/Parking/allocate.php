<?php
    include_once'db/connect.php';
    session_start();
    if($_SESSION['username']==""){
        header('location:index.php');
    }else{
        if($_SESSION['role']=="admin"){
          include_once'head/adminheader.php';
        }else{
            include_once'head/guardheader.php';
        }
    }
    error_reporting(0);
	
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Slot Allocations
      </h1>
      <hr>
    </section>

    <section class="content container-fluid">
        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title">Allocations done</h3>
                <a href="allocatenew.php" class="btn btn-success btn-sm pull-right">New Allocation</a>
            </div>
            <div class="box-body">
                <div style="overflow-x:auto;">
                    <table class="table table-striped" id="myOrder">
                        <thead>
                            <tr>
                                <th style="width:20px;">No</th>
								<th style="width:100px;">Registration Plate</th>
								<th style="width:50px;">Brand</th>
								<th style="width:50px;">Slot Allocated</th>
                                <th style="width:60px;">Served by</th>
                                <th style="width:50px;">Date</th>
								<th style="width:50px;">Time in</th>
								<th style="width:50px;">Time out</th>
                                <th style="width:70px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            $select = $pdo->prepare("SELECT * FROM report ORDER BY id DESC");
                            $select->execute();
                            while($row=$select->fetch(PDO::FETCH_OBJ)){
                            ?>
                                <tr>
                                <td><?php echo $no++ ; ?></td>
								<td><?php echo $row->registration_plate; ?></td>
								<td><?php echo $row->brand; ?></td>
								<td><?php echo $row->slot_number; ?></td>
                                <td class="text-uppercase"><?php echo $row->served_by; ?></td>
                                <td><?php echo $row->date; ?></td>
								<td><?php echo $row->time_in; ?></td>
								<td><?php echo $row->time_out; ?></td>
                                <td>
                                    <?php if($_SESSION['role']=="admin"){ ?>
									
                                    <a href="deleteallocate.php?id=<?php echo $row->ID; ?>" 
										onclick="return confirm('Delete Allocation?')"
										class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
									<?php } ?>
									<a href="updateallocate.php?id=<?php echo $row->ID; ?>"
										class="btn btn-info btn-sm" name="btn_edit"><i class="fa fa-pencil"></i></a>
                                    <a href="receipt.php?id=<?php echo $row->ID; ?>" 
										target="_blank" class="btn btn-info btn-sm">
									<i class="fa fa-print"></i></a>
                                </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>


    </section>
  </div>

  <script>
  $(document).ready( function () {
      $('#myOrder').DataTable();
  } );
  </script>

 <?php
    include_once'head/footer.php';
 ?>