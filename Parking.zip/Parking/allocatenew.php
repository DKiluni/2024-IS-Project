<?php
   include_once'db/connect.php';
    session_start();
    if($_SESSION['username']==""){
      header('location:index.php');
    }else{
      if($_SESSION['role']=="admin"){
        include_once'head/adminheader.php';
      }else{
          include_once'head/guardheader.php';
      }
    }

error_reporting(0);
date_default_timezone_set('Africa/Nairobi');

function fill_vehicle($pdo)
{
    $output = '';
    $select = $pdo->prepare("SELECT * FROM vehicles");
    $select->execute();
    $result = $select->fetchAll();

    foreach ($result as $row) {
        $output .= '<option value="' . $row['ID'] . '">' . $row["registration_plate"] . '</option>';
    }

    return $output;
}

function fill_slot($pdo)
{
    $output = '';
    $select = $pdo->prepare("SELECT * FROM slots WHERE is_occupied = 0");
    $select->execute();
    $result = $select->fetchAll();

    foreach ($result as $row) {
        $output .= '<option value="' . $row['slot_number'] . '">' . $row["slot_number"] . '</option>';
    }

    return $output;
}

if (isset($_POST['save_allocation'])) {
    $served_by = $_POST['served_by'];
    $date = date("Y-m-d", strtotime($_POST['date']));
    $time_in = date("H:i", strtotime($_POST['time_in']));
	

    $registration_plate = $_POST['registration_plate'];
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $colour = $_POST['colour'];
    $owner = $_POST['owner'];
    $contact = $_POST['contact'];
    $gender = $_POST['gender'];
	$roles = $_POST['roles'];
    $slot_number = $_POST['slot_number'];

    if ($registration_plate =="") {
        echo '<script type="text/javascript">
                jQuery(function validation(){
                swal("Warning", "No allocation to save.", "warning", {
                button: "Continue",
                    });
                });
              </script>';
    } else {
        $insert = $pdo->prepare("INSERT INTO report (registration_plate, brand, model, colour, owner, contact, gender, roles, slot_number, date, time_in, served_by) 
        VALUES (:registration_plate, :brand, :model, :colour, :owner, :contact, :gender, :roles, :slot_number, :date, :time_in, :served_by)");

        $insert->bindParam(':registration_plate', $registration_plate);
        $insert->bindParam(':brand', $brand);
        $insert->bindParam(':model', $model);
        $insert->bindParam(':colour', $colour);
        $insert->bindParam(':owner', $owner);
        $insert->bindParam(':contact', $contact);
		$insert->bindParam(':gender', $gender);
		$insert->bindParam(':roles', $roles);
        $insert->bindParam(':slot_number', $slot_number);
        $insert->bindParam(':date', $date);
        $insert->bindParam(':time_in', $time_in);
        $insert->bindParam(':served_by', $served_by);

        if ($insert->execute()) {
			
			$update = $pdo->prepare("UPDATE slots SET is_occupied = 1 WHERE slot_number = :slot_number");
            $update->bindParam(':slot_number', $slot_number);
            $update->execute();
			
            echo '<script type="text/javascript">
                    jQuery(function validation(){
                    swal("Success", "Allocation is Successful", "success", {
                    button: "Continue",
                        });
                    });
                  </script>';
        }
    }
}
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Allocate Slot</h1>
        <hr>
    </section>

    <section class="content container-fluid">
        <div class="box box-success">
            <form action="" method="POST">
                <div class="box-body">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>User Name</label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-user"></i>
                                </div>
                                <input type="text" class="form-control pull-right" name="served_by" value="<?php echo $_SESSION['username']; ?>" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Allocation Date</label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" class="form-control pull-right" name="date" value="<?php echo date("d-m-Y"); ?>" readonly data-date-format="yyyy-mm-dd">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Allocation Time</label>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-clock-o"></i>
                                </div>
                                <input type="text" class="form-control pull-right" name="time_in" value="<?php echo date('H:i'); ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="box-body">
                    <div class="col-md-12" style="overflow-x:auto;">
                        <table class="table table-border" id="myOrder">
                            <thead>
                                <tr>
									<th></th>
                                    <th>Registration Plate</th>
                                    <th>Brand</th>
                                    <th>Model</th>
                                    <th>Colour</th>
                                    <th>Owner</th>
                                    <th>Contact</th>
                                    <th>Gender</th>
									<th>Role</th>
									<th>Slot No</th>
                                    <th>
                                        <button type="button" name="addOrder" class="btn btn-success btn-sm btn_addOrder" required>
                                            <span>
                                                <i class="fa fa-plus"></i>
                                            </span>
                                        </button>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
							
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="box-footer" align="center">
                    <input type="submit" name="save_allocation" value="Save Allocation" class="btn btn-success">
                    <a href="allocate.php" class="btn btn-warning">Back</a>
                </div>
            </form>
        </div>
    </section>
</div>

<script>
$(document).ready(function(){
    $(document).on('click','.btn_addOrder', function(){
        var html='';
        html+='<tr>';
		html+='<td><input type="hidden" class="form-control registration_plate" name="registration_plate" readonly></td>';
        html+='<td><select class="form-control id" name="id[]" style="width:120px;" required><option value="" disabled selected hidden>--Select Vehicle--</option><?php echo fill_vehicle($pdo); ?></select></td>';
        html+='<td><input type="text" class="form-control brand" style="width:100px;" name="brand" readonly></td>';
        html+='<td><input type="text" class="form-control model" style="width:100px;" name="model" readonly></td>';
        html+='<td><input type="text" class="form-control colour" style="width:100px;" name="colour" readonly></td>';
        html+='<td><input type="text" class="form-control owner" style="width:100px;" name="owner" readonly></td>';
        html+='<td><input type="tel" class="form-control contact" style="width:100px;" name="contact" readonly></td>';
        html+='<td><input type="text" class="form-control gender" style="width:100px;" name="gender" readonly></td>';
		html+='<td><input type="text" class="form-control roles" style="width:100px;" name="roles" readonly></td>';
		html+='<td><select class="form-control slot_number" name="slot_number" style="width:120px;" required><option value="" disabled selected hidden>--Select Slot--</option><?php echo fill_slot($pdo); ?></select></td>';
        html+='<td><button type="button" name="remove" class="btn btn-danger btn-sm btn-remove"><i class="fa fa-remove"></i></button></td>';
        html+='</tr>';

        $('#myOrder tbody').append(html);

        $('.id').on('change', function(){
            var ID = $(this).val();
            var tr = $(this).closest('tr');
            $.ajax({
                url: "getvehicle.php",
                method: "GET",
                data: { ID: ID },
                success: function(data){
                    tr.find(".registration_plate").val(data.registration_plate);
                    tr.find(".brand").val(data.brand);
                    tr.find(".model").val(data.model);
                    tr.find(".colour").val(data.colour);
                    tr.find(".owner").val(data.owner);
                    tr.find(".contact").val(data.contact);
                    tr.find(".gender").val(data.gender);
					tr.find(".roles").val(data.roles);
                }
            });
        });
    });

    $(document).on('click', '.btn-remove', function(){
        $(this).closest('tr').remove();
    });
});
</script>

<?php
include_once 'head/footer.php';
?>
